-- MySQL dump 10.13  Distrib 5.7.16, for Linux (x86_64)
--
-- Host: localhost    Database: fias2
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `actual_statuses`
--

LOCK TABLES `actual_statuses` WRITE;
/*!40000 ALTER TABLE `actual_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `actual_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `address_object`
--

LOCK TABLES `address_object` WRITE;
/*!40000 ALTER TABLE `address_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `address_object_type`
--

LOCK TABLES `address_object_type` WRITE;
/*!40000 ALTER TABLE `address_object_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_object_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `center_status`
--

LOCK TABLES `center_status` WRITE;
/*!40000 ALTER TABLE `center_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `center_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `current_status`
--

LOCK TABLES `current_status` WRITE;
/*!40000 ALTER TABLE `current_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `current_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `estate_status`
--

LOCK TABLES `estate_status` WRITE;
/*!40000 ALTER TABLE `estate_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `estate_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `house`
--

LOCK TABLES `house` WRITE;
/*!40000 ALTER TABLE `house` DISABLE KEYS */;
/*!40000 ALTER TABLE `house` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `house_interval`
--

LOCK TABLES `house_interval` WRITE;
/*!40000 ALTER TABLE `house_interval` DISABLE KEYS */;
/*!40000 ALTER TABLE `house_interval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `house_status`
--

LOCK TABLES `house_status` WRITE;
/*!40000 ALTER TABLE `house_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `house_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `interv_status`
--

LOCK TABLES `interv_status` WRITE;
/*!40000 ALTER TABLE `interv_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `interv_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `landmark`
--

LOCK TABLES `landmark` WRITE;
/*!40000 ALTER TABLE `landmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `landmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `last_update`
--

LOCK TABLES `last_update` WRITE;
/*!40000 ALTER TABLE `last_update` DISABLE KEYS */;
INSERT INTO `last_update` (`last_update_id`, `last_update_date`) VALUES (1,'2016-11-21');
/*!40000 ALTER TABLE `last_update` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `norm_doc`
--

LOCK TABLES `norm_doc` WRITE;
/*!40000 ALTER TABLE `norm_doc` DISABLE KEYS */;
/*!40000 ALTER TABLE `norm_doc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `norm_doc_type`
--

LOCK TABLES `norm_doc_type` WRITE;
/*!40000 ALTER TABLE `norm_doc_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `norm_doc_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `operation_statuses`
--

LOCK TABLES `operation_statuses` WRITE;
/*!40000 ALTER TABLE `operation_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `operation_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `stead`
--

LOCK TABLES `stead` WRITE;
/*!40000 ALTER TABLE `stead` DISABLE KEYS */;
/*!40000 ALTER TABLE `stead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `structure_status`
--

LOCK TABLES `structure_status` WRITE;
/*!40000 ALTER TABLE `structure_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `structure_status` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-28 16:23:06
